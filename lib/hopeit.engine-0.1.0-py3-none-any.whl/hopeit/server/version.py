"""
Engine version constants.
Increment on release
"""
ENGINE_NAME = "hopeit.engine"
ENGINE_VERSION = "0.1.0"
