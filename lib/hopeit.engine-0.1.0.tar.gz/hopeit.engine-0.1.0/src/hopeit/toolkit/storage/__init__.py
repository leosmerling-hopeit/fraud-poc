"""
Storage/persistence methods supported by the engine
"""
__all__ = ['fs',
           'redis']
